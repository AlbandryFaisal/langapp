import 'package:flutter/material.dart';
import 'package:langapp/screens/RLSW/writing.dart';
import 'package:lottie/lottie.dart';
import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:after_layout/after_layout.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'screens/login_page.dart';
import 'Splash/inital.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  await Hive.openBox("LocalDB");

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return DynamicColorBuilder(
      builder: (ColorScheme? lightDynamic, ColorScheme? darkDynamic) {
        final ColorScheme lightFallback =
            ColorScheme.fromSwatch(primarySwatch: Colors.blue);
        final ColorScheme darkFallback = ColorScheme.fromSwatch(
            primarySwatch: Colors.blue, brightness: Brightness.dark);

        return MaterialApp(
          title: 'LANGGG',
          theme: ThemeData(
              fontFamily: 'Ubuntu',
              colorScheme: lightDynamic ?? lightFallback,
              useMaterial3: true),
          darkTheme: ThemeData(
              fontFamily: 'Ubuntu',
              colorScheme: darkDynamic ?? darkFallback,
              brightness: Brightness.dark,
              useMaterial3: true),
          debugShowCheckedModeBanner: false,
          home: Splash(
            dync: lightDynamic ?? lightFallback,
          ),
        );
      },
    );
  }
}

class Splash extends StatefulWidget {
  final ColorScheme dync;
  const Splash({required this.dync});

  @override
  SplashState createState() => SplashState();
}

class SplashState extends State<Splash> with AfterLayoutMixin<Splash> {
  Future<void> checkFirstSeen() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool _seen = prefs.getBool('seen') ?? false;

    if (_seen) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (context) => LoginPage(
                dync: widget.dync,
              )));
    } else {
      await prefs.setBool('seen', true);
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (context) => InitPage(
                dync: widget.dync,
              )));
    }
  }

  @override
  void afterFirstLayout(BuildContext context) => checkFirstSeen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.dync.tertiaryContainer,
      body: Center(child: Text("🐼 🐼 🐼")),
    );
  }
}
