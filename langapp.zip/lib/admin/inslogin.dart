import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Inslogin extends StatefulWidget {
  const Inslogin({super.key});

  @override
  State<Inslogin> createState() => _InsloginState();
}

class _InsloginState extends State<Inslogin> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}